# FREE RDP WINDOWS SERVER!

Create Free VPS 7GB RAM, 40 minute and 2 CPU Core with Github 
 

Follow these instructions

How to use

1.Chrome Remote Desktop (CRD)

 + Click Fork to get started (Mobile users please activate Desktop Mode)
 + Just Fork this Repository, Go to Actions tab, Select the "WindowsCRD" workflow. Then select Run Workflow fill the following data in CRD Code and your Pin in the fields. After that, Press Start.
 + Input the following code in the fields.
 + Get the Windows (Powershell) command from here:<https://remotedesktop.google.com/headless>
 + Enter you Six digit Pin code to Login
 + (Any Six digit Pin)
 + Thats it... After 2-3 min of Initialize, Check your CRD Application or Account.
 + keep cmd tab to run longer
.Done :)

2.Remote Desktop Microsoft (RDP)

 + Click Fork to get started (Mobile users please activate Desktop Mode).
 + Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
 + In this repository go to Settings> Secrets> New repository secret 
 + Name: NGROK_AUTH_TOKEN
 + Value: https://dashboard.ngrok.com/auth/your-authtoken copy and paste authtoken in the value
 + Click add secret
 + Go to Action (if you see any watning click "I understand...") > WindowsRDP > run workflow
 + Refresh website - go to test > build
 + Click the down arrow "." To get IP, User, Password.
 # WARNING!!
 + Use For Educational Purposes Only
 + No Exploitation Or Abuse Causing Loss of Account
 + Don't Run Virus

